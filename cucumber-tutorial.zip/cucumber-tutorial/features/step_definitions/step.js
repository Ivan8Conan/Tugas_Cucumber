import { Builder, By, until } from 'selenium-webdriver';
import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from 'chai';

setDefaultTimeout(30000);
let driver;

//Scenario: Successful login with valid details
Given("the user is on the login page", async function () {
  driver = new Builder().forBrowser("MicrosoftEdge").build();
  await driver.get("https://www.saucedemo.com/");
  await driver.sleep(2000);
});

When("the user enters a valid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("standard_user");
  await driver.findElement(By.id("password")).sendKeys("secret_sauce");
  await driver.sleep(3000);
});

When("the user clicks the login button", async function () {
  await driver.findElement(By.id("login-button")).click();
  await driver.sleep(2000);
});

Then("the user should see a success message", async function () {
  const message = await driver
    .wait(until.elementLocated(By.className("title")), 5000)
    .getText();
  expect(message).to.equal("Products");
  await driver.sleep(2000);
});

//Scenario: Failed login with invalid credential
When("the user enters an invalid username and password", async function () {
  await driver.findElement(By.id("user-name")).sendKeys("invalid_user");
  await driver.findElement(By.id("password")).sendKeys("wrong_password");
  await driver.sleep(1000);
});

Then("the user should see a failed message", async function () {
  const error = await driver
    .wait(until.elementLocated(By.css("[data-test='error']")), 5000)
    .getText();
  expect(error).to.include("Username and password do not match");
  await driver.sleep(1000);
  await driver.quit();
});

//Scenario: Add Item Cart Successfully
When("the user adds an item to the cart", async function () {
  await driver.wait(until.elementLocated(By.css('[data-test="add-to-cart-sauce-labs-backpack"]')), 5000).click();
  await driver.sleep(2000);
});

Then("the item should be visible in the cart page", async function () {
  await driver.findElement(By.className("shopping_cart_link")).click();
  await driver.sleep(1000);
  const cartItem = await driver.findElement(By.className("inventory_item_name")).getText();
  expect(cartItem).to.include("Backpack");
  await driver.sleep(3000);
  await driver.quit();
});

//Scenario: Remove Item Cart Successfully
When("the user removes the item from the cart", async function () {
  await driver.findElement(By.className("shopping_cart_link")).click();
  await driver.sleep(2000);
  await driver.wait(until.elementLocated(By.css('[data-test="remove-sauce-labs-backpack"]')), 5000).click();
  await driver.sleep(2000);
});

Then("the item should no longer be in the cart page", async function () {
  const cartItems = await driver.findElements(By.className("inventory_item_name"));
  expect(cartItems.length).to.equal(0);
  await driver.sleep(3000);
  await driver.quit();
});

//Scenario: Sort items name from Z to A
Given("the user is on the item page", async function () {
  const currentUrl = await driver.getCurrentUrl();
  expect(currentUrl).to.include("/inventory.html");
  await driver.sleep(1000);
});

When("the user selects {string} from the sort dropdown", async function (sortOption) {
  const dropdown = await driver.findElement(By.className("product_sort_container"));
  await dropdown.sendKeys(sortOption);
  await driver.sleep(2000);
});

Then("the items should be sorted in descending order by name", async function () {
  const items = await driver.findElements(By.className("inventory_item_name"));
  const itemNames = await Promise.all(items.map((item) => item.getText()));
  expect(itemNames).to.deep.equal(itemNames.sort().reverse());
  await driver.sleep(3000);
  await driver.quit();
});

// Scenario: Logout successfully
When("the user is redirected to the inventory page", async function () {
  const url = await driver.getCurrentUrl();
  expect(url).to.include("/inventory.html");
  await driver.sleep(1000);
});

When("the user clicks the menu button", async function () {
  await driver.wait(until.elementLocated(By.id("react-burger-menu-btn")), 5000).click();
  await driver.sleep(2000);
});

When("the user clicks the logout link", async function () {
  const logoutLink = await driver.wait(until.elementLocated(By.id("logout_sidebar_link")), 5000);
  await driver.sleep(2000);
  await logoutLink.click();
  await driver.sleep(2000);
});

Then("the user should be redirected to the login page", async function () {
  await driver.wait(until.urlIs("https://www.saucedemo.com/"), 5000);
  const currentUrl = await driver.getCurrentUrl();
  expect(currentUrl).to.equal("https://www.saucedemo.com/");
  await driver.sleep(2000);
  await driver.quit();
});

